package modelos;

import db.DatabaseHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

public class Estadisticas {

    public static Map<String, Integer> obtenerConteoEntradasSalidas(DatabaseHandler db) throws SQLException {
        Map<String, Integer> conteo = new LinkedHashMap<>();
        conteo.put("Entrada", 0);
        conteo.put("Salida", 0);

        String sql = "SELECT permitido, COUNT(*) AS cantidad FROM accesos GROUP BY permitido;";
        return db.query(sql, (ResultSet rs) -> {
            while (rs.next()) {
                boolean permitido = rs.getBoolean("permitido");
                int cantidad = rs.getInt("cantidad");
                if (permitido) conteo.put("Entrada", cantidad);
                else conteo.put("Salida", cantidad);
            }
            return conteo;
        });
    }

    public static Map<String, Integer> accesosPorDia(DatabaseHandler db) throws SQLException {
        String sql = "SELECT TO_CHAR(fecha, 'YYYY-MM-DD') AS fecha, COUNT(*) AS cantidad FROM accesos GROUP BY fecha ORDER BY fecha;";
        return db.query(sql, (ResultSet rs) -> {
            Map<String,Integer> res = new LinkedHashMap<>();
            while (rs.next()) res.put(rs.getString("fecha"), rs.getInt("cantidad"));
            return res;
        });
    }
}
