package modelos;

import db.DatabaseHandler;
import db.ResultSetHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Usuario extiende Persona. Mantiene rol (ADMIN/OPERADOR/USUARIO).
 * Tiene métodos: guardar, actualizar(persona+rol), obtenerPorDocumento, obtenerTodos, eliminar, crearTabla
 */
public class Usuario extends Persona {

    private String rol; // ADMIN, OPERADOR, USUARIO

    public Usuario(String documento, String nombre, String correo) {
        super(documento, nombre, correo);
        this.rol = "USUARIO";
    }

    public Usuario(String documento, String nombre, String correo, String rol) {
        super(documento, nombre, correo);
        this.rol = (rol == null) ? "USUARIO" : rol.toUpperCase();
    }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = (rol == null) ? "USUARIO" : rol.toUpperCase(); }

    @Override
    public void guardar(DatabaseHandler db) throws SQLException {
        super.guardar(db);
        String sql = "INSERT INTO usuarios (documento, rol) VALUES (?, ?) ON CONFLICT (documento) DO UPDATE SET rol = EXCLUDED.rol;";
        db.executeUpdate(sql, documento, rol);
    }

    /**
     * Actualiza datos de persona y rol en usuarios.
     */
    public void actualizar(DatabaseHandler db, String nuevoNombre, String nuevoCorreo, String nuevoRol) throws SQLException {
        super.actualizar(db, nuevoNombre, nuevoCorreo);
        String sql = "INSERT INTO usuarios (documento, rol) VALUES (?, ?) ON CONFLICT (documento) DO UPDATE SET rol = EXCLUDED.rol;";
        db.executeUpdate(sql, documento, nuevoRol == null ? this.rol : nuevoRol);
        this.rol = (nuevoRol == null) ? this.rol : nuevoRol.toUpperCase();
    }

    public static Usuario obtenerPorDocumento(DatabaseHandler db, String documento) throws SQLException {
        String sql = "SELECT p.documento, p.nombre, p.correo, COALESCE(u.rol,'USUARIO') AS rol " +
                     "FROM personas p LEFT JOIN usuarios u ON p.documento = u.documento WHERE p.documento = ?;";
        return db.query(sql, (ResultSet rs) -> {
            if (rs.next()) {
                return new Usuario(rs.getString("documento"), rs.getString("nombre"), rs.getString("correo"), rs.getString("rol"));
            }
            return null;
        }, documento);
    }

    public static List<Usuario> obtenerTodos(DatabaseHandler db) throws SQLException {
        String sql = "SELECT p.documento, p.nombre, p.correo, COALESCE(u.rol,'USUARIO') AS rol FROM personas p JOIN usuarios u ON p.documento = u.documento;";
        return db.query(sql, (ResultSet rs) -> {
            List<Usuario> list = new ArrayList<>();
            while (rs.next()) {
                list.add(new Usuario(rs.getString("documento"), rs.getString("nombre"), rs.getString("correo"), rs.getString("rol")));
            }
            return list;
        });
    }

    public static void eliminar(DatabaseHandler db, String documento) throws SQLException {
        String sql = "DELETE FROM usuarios WHERE documento = ?;";
        db.executeUpdate(sql, documento);
        // Nota: mantenemos registro en personas (si quieres borrar persona también, modifica aquí)
    }

    public static void crearTabla(DatabaseHandler db) throws SQLException {
        Persona.crearTabla(db);
        String sql = "CREATE TABLE IF NOT EXISTS usuarios (" +
                     "documento VARCHAR(50) PRIMARY KEY REFERENCES personas(documento) ON DELETE CASCADE, " +
                     "rol VARCHAR(20) NOT NULL DEFAULT 'USUARIO');";
        db.executeUpdate(sql);
    }
}
