package modelos;

import db.DatabaseHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Acceso {
    private int id;
    private String documento_persona;
    private String zona;
    private boolean permitido;
    private LocalDateTime fecha;

    public Acceso(String documento_persona, String zona, boolean permitido, LocalDateTime fecha) {
        this.documento_persona = documento_persona;
        this.zona = zona;
        this.permitido = permitido;
        this.fecha = (fecha != null) ? fecha : LocalDateTime.now();
    }

    public String getDocumento_persona() { return documento_persona; }
    public String getZona() { return zona; }
    public boolean isPermitido() { return permitido; }
    public LocalDateTime getFecha() { return fecha; }

    public boolean registrar(DatabaseHandler db) throws SQLException {
        String sql = "INSERT INTO accesos (documento_persona, zona, permitido, fecha) VALUES (?, ?, ?, ?);";
        db.executeUpdate(sql, documento_persona, zona, permitido, Timestamp.valueOf(fecha));
        return true;
    }

    public static void crearTabla(DatabaseHandler db) throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS accesos (" +
                "id SERIAL PRIMARY KEY, " +
                "documento_persona VARCHAR(50) NOT NULL, " +
                "zona VARCHAR(100) NOT NULL, " +
                "fecha TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                "permitido BOOLEAN NOT NULL, " +
                "FOREIGN KEY (documento_persona) REFERENCES usuarios(documento) ON DELETE CASCADE);";
        db.executeUpdate(sql);
    }

    public static List<Acceso> obtenerUltimos(DatabaseHandler db, int limit) throws SQLException {
        String sql = "SELECT id, documento_persona, zona, permitido, fecha FROM accesos ORDER BY fecha DESC LIMIT ?;";
        return db.query(sql, (ResultSet rs) -> {
            List<Acceso> list = new ArrayList<>();
            while (rs.next()) {
                Acceso a = new Acceso(rs.getString("documento_persona"), rs.getString("zona"), rs.getBoolean("permitido"), rs.getTimestamp("fecha").toLocalDateTime());
                a.id = rs.getInt("id");
                list.add(a);
            }
            return list;
        }, limit);
    }
}
