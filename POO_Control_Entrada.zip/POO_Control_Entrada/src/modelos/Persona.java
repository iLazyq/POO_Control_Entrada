package modelos;

import db.DatabaseHandler;
import db.ResultSetHandler;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Persona {
    protected String documento;
    protected String nombre;
    protected String correo;

    public Persona(String documento, String nombre, String correo) {
        this.documento = documento;
        this.nombre = nombre;
        this.correo = correo;
    }

    public String getDocumento() { return documento; }
    public String getNombre() { return nombre; }
    public String getCorreo() { return correo; }

    public void guardar(DatabaseHandler db) throws SQLException {
        String sql = "INSERT INTO personas (documento, nombre, correo) VALUES (?, ?, ?) " +
                     "ON CONFLICT (documento) DO UPDATE SET nombre = EXCLUDED.nombre, correo = EXCLUDED.correo;";
        db.executeUpdate(sql, documento, nombre, correo);
    }

    public void actualizar(DatabaseHandler db, String nuevoNombre, String nuevoCorreo) throws SQLException {
        String nombreFinal = (nuevoNombre != null && !nuevoNombre.trim().isEmpty()) ? nuevoNombre : this.nombre;
        String correoFinal = (nuevoCorreo != null && !nuevoCorreo.trim().isEmpty()) ? nuevoCorreo : this.correo;
        String sql = "UPDATE personas SET nombre = ?, correo = ? WHERE documento = ?;";
        db.executeUpdate(sql, nombreFinal, correoFinal, documento);
        this.nombre = nombreFinal;
        this.correo = correoFinal;
    }

    public static Persona obtenerPorDocumento(DatabaseHandler db, String documento) throws SQLException {
        String sql = "SELECT documento, nombre, correo FROM personas WHERE documento = ?;";
        return db.query(sql, (ResultSet rs) -> {
            if (rs.next()) return new Persona(rs.getString("documento"), rs.getString("nombre"), rs.getString("correo"));
            return null;
        }, documento);
    }

    public static void crearTabla(DatabaseHandler db) throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS personas (" +
                     "documento VARCHAR(50) PRIMARY KEY, " +
                     "nombre VARCHAR(100) NOT NULL, " +
                     "correo VARCHAR(100) UNIQUE NOT NULL);";
        db.executeUpdate(sql);
    }
}
