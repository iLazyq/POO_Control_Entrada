package modelos;

import db.DatabaseHandler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Tecnico extends Persona {
    private String especialidad;

    public Tecnico(String documento, String nombre, String correo) {
        super(documento, nombre, correo);
    }

    public Tecnico(String documento, String nombre, String correo, String especialidad) {
        super(documento, nombre, correo);
        this.especialidad = especialidad;
    }

    public String getEspecialidad() { return especialidad; }

    public void guardar(DatabaseHandler db) throws SQLException {
        super.guardar(db);
        String sql = "INSERT INTO tecnicos (documento, especialidad) VALUES (?, ?) ON CONFLICT (documento) DO UPDATE SET especialidad = EXCLUDED.especialidad;";
        db.executeUpdate(sql, documento, especialidad);
    }

    public static Tecnico obtenerPorDocumento(DatabaseHandler db, String documento) throws SQLException {
        String sql = "SELECT t.documento, p.nombre, p.correo, t.especialidad FROM tecnicos t JOIN personas p ON t.documento = p.documento WHERE t.documento = ?;";
        return db.query(sql, (ResultSet rs) -> {
            if (rs.next()) return new Tecnico(rs.getString("documento"), rs.getString("nombre"), rs.getString("correo"), rs.getString("especialidad"));
            return null;
        }, documento);
    }

    public static void crearTabla(DatabaseHandler db) throws SQLException {
        Persona.crearTabla(db);
        String sql = "CREATE TABLE IF NOT EXISTS tecnicos (" +
                "documento VARCHAR(50) PRIMARY KEY REFERENCES personas(documento) ON DELETE CASCADE," +
                "especialidad VARCHAR(150));";
        db.executeUpdate(sql);
    }
}
