package utils;

/**
 * Manejo simple de sesión en memoria.
 * startSession(documento, nombre, rol)
 * endSession()
 * Consultas: getDoc(), getName(), getRole(), isAdmin(), isOperador(), isUsuario()
 */
public class SessionManager {
    private static String doc;
    private static String name;
    private static String role;

    public static void startSession(String documento, String nombre, String rol) {
        doc = documento;
        name = nombre;
        role = (rol == null) ? "USUARIO" : rol.toUpperCase();
    }

    public static void endSession() {
        doc = null; name = null; role = null;
    }

    public static String getDoc() { return doc; }
    public static String getName() { return name; }
    public static String getRole() { return role; }

    public static boolean isAdmin() { return "ADMIN".equalsIgnoreCase(role); }
    public static boolean isOperador() { return "OPERADOR".equalsIgnoreCase(role); }
    public static boolean isUsuario() { return "USUARIO".equalsIgnoreCase(role); }
}
