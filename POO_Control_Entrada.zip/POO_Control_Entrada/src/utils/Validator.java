package utils;

public class Validator {
    public static boolean isEmpty(String s) { return s == null || s.trim().isEmpty(); }
    public static void requireNotEmpty(String v, String m) { if (isEmpty(v)) throw new IllegalArgumentException(m); }
}
