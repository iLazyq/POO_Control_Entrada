package main;

import db.DatabaseHandler;
import interfaz.LoginFrame;

import javax.swing.*;

public class Main {

    private static final String DATABASE_URL =
            "postgresql://postgres:DYiwMnjmkIGmktUXIPBydyYcgqOjdUXp@centerbeam.proxy.rlwy.net:55494/railway";

    public static void main(String[] args) {
        DatabaseHandler db;
        try {
            db = new DatabaseHandler(DATABASE_URL);
            System.out.println("✅ Conexión establecida.");
        } catch (Exception e) {
            System.err.println("❌ Error al conectar:");
            e.printStackTrace();
            return;
        }

        try {
            modelos.Persona.crearTabla(db);
            modelos.Usuario.crearTabla(db);
            modelos.Tecnico.crearTabla(db);
            modelos.Acceso.crearTabla(db);
            System.out.println("✅ Tablas listas.");
        } catch (Exception e) {
            System.err.println("❌ Error creando tablas:");
            e.printStackTrace();
            db.close();
            return;
        }

        SwingUtilities.invokeLater(() -> {
            LoginFrame login = new LoginFrame(db);
            login.setVisible(true);
        });
    }
}
