package servicios;

import db.DatabaseHandler;
import modelos.Estadisticas;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Map;

public class ExportService {

    private final DatabaseHandler db;

    public ExportService(DatabaseHandler db) {
        this.db = db;
    }

    public void exportarEstadisticasCSV(File file) throws Exception {
        Map<String, Integer> conteo = Estadisticas.obtenerConteoEntradasSalidas(db);
        Map<String, Integer> porDia = Estadisticas.accesosPorDia(db);

        try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
            pw.println("Entradas vs Salidas");
            pw.println("Tipo,Cantidad");
            for (Map.Entry<String, Integer> e : conteo.entrySet()) {
                pw.printf("%s,%d%n", e.getKey(), e.getValue());
            }
            pw.println();
            pw.println("Accesos por Dia");
            pw.println("Fecha,Cantidad");
            for (Map.Entry<String, Integer> e : porDia.entrySet()) {
                pw.printf("%s,%d%n", e.getKey(), e.getValue());
            }
            pw.flush();
        }
    }
}
