package servicios;

import db.DatabaseHandler;
import modelos.Usuario;
import utils.Validator;

import java.sql.SQLException;
import java.util.List;

/**
 * Servicio para manejar reglas de negocio del usuario.
 * - crearUsuario: ADMIN puede crear cualquier rol; OPERADOR solo puede crear USUARIO u OPERADOR? (se limita abajo)
 * - actualizarUsuario: ADMIN puede actualizar rol, OPERADOR/USUARIO limitados
 * - eliminarUsuario: solo ADMIN
 *
 * Las comprobaciones se realizan usando el rol en SessionManager (si quieres usar la sesión aquí, pásala o verifica externamente).
 */
public class UsuarioService {

    private final DatabaseHandler db;

    public UsuarioService(DatabaseHandler db) {
        this.db = db;
    }

    /**
     * Crea usuario con rol. Asume validaciones externas del caller (verificar SessionManager).
     */
    public boolean crearUsuario(String documento, String nombre, String correo, String rol) throws Exception {
        Validator.requireNotEmpty(documento, "Documento vacío");
        Validator.requireNotEmpty(nombre, "Nombre vacío");
        Validator.requireNotEmpty(correo, "Correo vacío");
        if (rol == null || rol.trim().isEmpty()) rol = "USUARIO";
        rol = rol.toUpperCase();

        Usuario existente = Usuario.obtenerPorDocumento(db, documento);
        if (existente != null) return false;

        Usuario u = new Usuario(documento, nombre, correo, rol);
        u.guardar(db);
        return true;
    }

    /**
     * Actualiza usuario. El caller debe comprobar permisos: solo ADMIN puede cambiar rol a ADMIN o eliminar.
     */
    public boolean actualizarUsuario(String documento, String nombre, String correo, String rol) throws SQLException {
        Usuario u = Usuario.obtenerPorDocumento(db, documento);
        if (u == null) return false;
        // si rol == null -> mantiene rol actual
        u.actualizar(db, nombre, correo, rol);
        return true;
    }

    public List<Usuario> listarUsuarios() throws SQLException {
        return Usuario.obtenerTodos(db);
    }

    public void eliminarUsuario(String documento) throws SQLException {
        Usuario.eliminar(db, documento);
    }

    public Usuario obtener(String documento) throws SQLException {
        return Usuario.obtenerPorDocumento(db, documento);
    }
}
