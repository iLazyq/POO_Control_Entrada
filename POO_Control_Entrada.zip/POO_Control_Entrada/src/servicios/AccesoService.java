package servicios;

import db.DatabaseHandler;
import modelos.Acceso;

import java.sql.SQLException;
import java.util.List;

public class AccesoService {

    private final DatabaseHandler db;

    public AccesoService(DatabaseHandler db) {
        this.db = db;
    }

    /**
     * Registra acceso: tipo "entrada" -> permitido=true; "salida" -> permitido=false
     * No realiza comprobaciones sobre rol: el caller (InterfazGUI) debe limitar quién puede usarlo.
     */
    public boolean registrarAcceso(String documento, String zona, String tipo) throws SQLException {
        boolean permitido = "entrada".equalsIgnoreCase(tipo);
        Acceso acc = new Acceso(documento, zona, permitido, null);
        return acc.registrar(db);
    }

    public List<Acceso> listarUltimos(int limit) throws SQLException {
        return Acceso.obtenerUltimos(db, limit);
    }
}
