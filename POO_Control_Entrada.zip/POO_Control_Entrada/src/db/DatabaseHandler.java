package db;

import java.sql.*;

public class DatabaseHandler {
    private Connection conn;

    // Recibe URL tipo: postgresql://user:pass@host:port/db
    public DatabaseHandler(String fullUrl) {
        String jdbc = transformToJdbc(fullUrl);
        connect(jdbc);
    }

    private void connect(String jdbcUrl) {
        try {
            Class.forName("org.postgresql.Driver");
            // Intentamos parsear user/password desde query si vienen, aunque preferimos pasarlos separados.
            // Aquí usamos getConnection(jdbc) porque transformToJdbc ya añade user&password.
            conn = DriverManager.getConnection(jdbcUrl);
            conn.setAutoCommit(true);
            System.out.println("Conectado a DB");
        } catch (Exception e) {
            throw new RuntimeException("Error conectando a la base de datos: " + jdbcUrlMessage(jdbcUrlSafe(jdbcUrlFromException(e))), e);
        }
    }

    // Helper to create a safe message (we don't leak password).
    private String jdbcUrlMessage(String s) { return s; }

    // A safe placeholder used only if error message needs it.
    private String jdbcUrlFromException(Exception e) { return ""; }
    private String jdbcUrlSafe(String s) { return s; }

    // Transform: postgresql://user:pass@host:port/db -> jdbc:postgresql://host:port/db?user=...&password=...&sslmode=require
    private static String transformToJdbc(String url) {
        if (!url.startsWith("postgresql://")) return url;
        try {
            String without = url.substring("postgresql://".length());
            String[] parts = without.split("@", 2);
            String userPass = parts[0];
            String hostDb = parts[1];

            String[] up = userPass.split(":", 2);
            String user = up[0];
            String pass = up.length > 1 ? up[1] : "";

            String[] hd = hostDb.split("/", 2);
            String hostPort = hd[0];
            String database = hd.length > 1 ? hd[1] : "";

            // sslmode=require (Railway often requires SSL)
            return "jdbc:postgresql://" + hostPort + "/" + database +
                    "?user=" + urlEncode(user) + "&password=" + urlEncode(pass) + "&sslmode=require";
        } catch (Exception e) {
            throw new RuntimeException("URL PostgreSQL inválida: " + url, e);
        }
    }

    private static String urlEncode(String s) {
        if (s == null) return "";
        return s.replace(" ", "%20").replace("&", "%26").replace("?", "%3F");
    }

    // Execute update
    public void executeUpdate(String sql, Object... params) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            setParams(stmt, params);
            stmt.executeUpdate();
        }
    }

    // Query with handler to close resources
    public <T> T query(String sql, ResultSetHandler<T> handler, Object... params) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            setParams(stmt, params);
            try (ResultSet rs = stmt.executeQuery()) {
                return handler.handle(rs);
            }
        }
    }

    private void setParams(PreparedStatement st, Object... params) throws SQLException {
        if (params == null) return;
        for (int i = 0; i < params.length; i++) {
            st.setObject(i + 1, params[i]);
        }
    }

    public Connection getConnection() { return conn; }

    public void close() {
        try { if (conn != null && !conn.isClosed()) conn.close(); } catch (SQLException ignored) {}
    }
}
