package interfaz;

import db.DatabaseHandler;
import utils.SessionManager;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private final DatabaseHandler db;

    public MainFrame(DatabaseHandler db) {
        this.db = db;
        setTitle("Sistema - Usuario: " + SessionManager.getName() + " (" + SessionManager.getRole() + ")");
        setSize(1000,650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Menu con logout
        JMenuBar mb = new JMenuBar();
        JMenu m = new JMenu("Archivo");
        JMenuItem logout = new JMenuItem("Cerrar sesión");
        logout.addActionListener(e -> logout());
        m.add(logout);
        mb.add(m);
        setJMenuBar(mb);

        // Panel según rol
        JPanel panel;
        if (SessionManager.isAdmin()) panel = new AdminPanel(db, this);
        else if (SessionManager.isOperador()) panel = new OperadorPanel(db, this);
        else panel = new UsuarioPanel(db, this);

        add(panel, BorderLayout.CENTER);
    }

    private void logout() {
        // Close this frame, end session and show login
        SessionManager.endSession();
        dispose();
        SwingUtilities.invokeLater(() -> {
            new LoginFrame(db).setVisible(true);
        });
    }
}
