package interfaz;

import db.DatabaseHandler;
import servicios.UsuarioService;
import modelos.Usuario;
import utils.SessionManager;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {

    private final DatabaseHandler db;
    private final UsuarioService usuarioService;

    public LoginFrame(DatabaseHandler db) {
        this.db = db;
        this.usuarioService = new UsuarioService(db);

        setTitle("Login");
        setSize(360,180);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel p = new JPanel(new GridLayout(0,1,4,4));
        JTextField docField = new JTextField();
        p.add(new JLabel("Documento:"));
        p.add(docField);

        JButton loginBtn = new JButton("Iniciar sesión");
        loginBtn.addActionListener(e -> {
            String doc = docField.getText().trim();
            if (doc.isEmpty()) { JOptionPane.showMessageDialog(this,"Documento obligatorio"); return; }
            try {
                Usuario u = usuarioService.obtener(doc);
                if (u == null) {
                    int op = JOptionPane.showConfirmDialog(this, "Usuario no existe. ¿Crear nuevo usuario?", "Crear", JOptionPane.YES_NO_OPTION);
                    if (op == JOptionPane.YES_OPTION) {
                        CreateUserDialog cud = new CreateUserDialog(this, db, doc);
                        cud.setVisible(true);
                        u = usuarioService.obtener(doc);
                        if (u == null) return;
                    } else return;
                }
                // Iniciar sesión y abrir Interfaz principal
                SessionManager.startSession(u.getDocumento(), u.getNombre(), u.getRol());
                this.setVisible(false);
                InterfazGUI main = new InterfazGUI(db);
                main.setVisible(true);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error login: " + ex.getMessage());
            }
        });

        add(p, BorderLayout.CENTER);
        add(loginBtn, BorderLayout.SOUTH);
    }
}
