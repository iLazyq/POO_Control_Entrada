package interfaz;

import db.DatabaseHandler;
import servicios.UsuarioService;

import javax.swing.*;
import java.awt.*;

public class CreateUserDialog extends JDialog {
    public CreateUserDialog(Frame owner, DatabaseHandler db, String documentoInicial) {
        super(owner, "Crear usuario", true);
        UsuarioService us = new UsuarioService(db);

        JTextField doc = new JTextField(documentoInicial == null ? "" : documentoInicial);
        JTextField nombre = new JTextField();
        JTextField correo = new JTextField();
        JComboBox<String> rol = new JComboBox<>(new String[]{"ADMIN","OPERADOR","USUARIO"});

        JPanel p = new JPanel(new GridLayout(0,1));
        p.add(new JLabel("Documento:")); p.add(doc);
        p.add(new JLabel("Nombre:")); p.add(nombre);
        p.add(new JLabel("Correo:")); p.add(correo);
        p.add(new JLabel("Rol:")); p.add(rol);

        JButton b = new JButton("Crear");
        b.addActionListener(e -> {
            try {
                boolean ok = us.crearUsuario(doc.getText().trim(), nombre.getText().trim(), correo.getText().trim(), (String)rol.getSelectedItem());
                if (ok) { JOptionPane.showMessageDialog(this,"Creado"); dispose(); }
                else JOptionPane.showMessageDialog(this,"No creado (ya existe)");
            } catch (Exception ex) { JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage()); }
        });

        getContentPane().add(p, BorderLayout.CENTER);
        getContentPane().add(b, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(owner);
    }
}
