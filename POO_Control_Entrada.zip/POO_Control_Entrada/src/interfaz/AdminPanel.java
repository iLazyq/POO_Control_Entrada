package interfaz;

import db.DatabaseHandler;
import servicios.UsuarioService;
import servicios.AccesoService;
import servicios.ExportService;
import utils.SessionManager;

import javax.swing.*;
import java.awt.*;

public class AdminPanel extends JPanel {
    private final DatabaseHandler db;
    private final JFrame parent;
    private final UsuarioService usuarioService;
    private final AccesoService accesoService;
    private final ExportService exportService;

    public AdminPanel(DatabaseHandler db, JFrame parent) {
        this.db = db; this.parent = parent;
        this.usuarioService = new UsuarioService(db);
        this.accesoService = new AccesoService(db);
        this.exportService = new ExportService(db);

        setLayout(new BorderLayout());
        JPanel top = new JPanel();
        JButton btnCreate = new JButton("Crear usuario");
        JButton btnList = new JButton("Listar usuarios");
        JButton btnStats = new JButton("Estadísticas");
        JButton btnExport = new JButton("Exportar CSV");

        top.add(btnCreate); top.add(btnList); top.add(btnStats); top.add(btnExport);
        add(top, BorderLayout.NORTH);

        JTextArea area = new JTextArea();
        add(new JScrollPane(area), BorderLayout.CENTER);

        btnCreate.addActionListener(e -> {
            CreateUserDialog cud = new CreateUserDialog(parent, db, null);
            cud.setVisible(true);
        });

        btnList.addActionListener(e -> {
            try {
                var list = usuarioService.listarUsuarios();
                StringBuilder sb = new StringBuilder();
                for (var u : list) sb.append(u.getDocumento()).append(" - ").append(u.getNombre()).append(" - ").append(u.getCorreo()).append(" - ").append(u.getRol()).append("\n");
                area.setText(sb.toString());
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage()); }
        });

        btnStats.addActionListener(e -> {
            try {
                var conteo = modelos.Estadisticas.obtenerConteoEntradasSalidas(db);
                var porDia = modelos.Estadisticas.accesosPorDia(db);
                StringBuilder sb = new StringBuilder("Entradas vs Salidas\n");
                conteo.forEach((k,v)-> sb.append(k).append(": ").append(v).append("\n"));
                sb.append("\nAccesos por dia\n");
                porDia.forEach((k,v)-> sb.append(k).append(": ").append(v).append("\n"));
                area.setText(sb.toString());
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage()); }
        });

        btnExport.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            fc.setSelectedFile(new java.io.File("estadisticas.csv"));
            if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                try {
                    exportService.exportarEstadisticasCSV(fc.getSelectedFile());
                    JOptionPane.showMessageDialog(this, "Exportado");
                } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error export: " + ex.getMessage()); }
            }
        });
    }
}
