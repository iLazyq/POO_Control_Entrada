package interfaz;

import db.DatabaseHandler;
import modelos.Usuario;
import modelos.Acceso;
import modelos.Estadisticas;
import servicios.UsuarioService;
import servicios.AccesoService;
import servicios.ExportService;
import utils.Validator;
import utils.SessionManager;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Interfaz principal con control de permisos por rol:
 * - ADMIN: todo
 * - OPERADOR: registrar accesos, ver historial, ver estadísticas (no eliminar/roles)
 * - USUARIO: ver su propio historial y ver sus datos (no registrar)
 *
 * Al cerrar sesión, cierra la ventana actual y vuelve al LoginFrame (solo queda el login).
 */
public class InterfazGUI extends JFrame {

    private final DatabaseHandler db;
    private final UsuarioService usuarioService;
    private final AccesoService accesoService;
    private final ExportService exportService;

    private final DefaultListModel<String> datosListaUsuarios = new DefaultListModel<>();
    private final JList<String> listaUsuarios = new JList<>(datosListaUsuarios);
    private final JLabel labelEstado = new JLabel(" ");
    private Timer refrescoTimer;
    private boolean autoRefresh = false;

    public InterfazGUI(DatabaseHandler db) {
        this.db = db;
        this.usuarioService = new UsuarioService(db);
        this.accesoService = new AccesoService(db);
        this.exportService = new ExportService(db);

        setTitle("Sistema de Control de Acceso - Usuario: " + SessionManager.getName() + " (" + SessionManager.getRole() + ")");
        setSize(1000, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // No loginDialog aquí (login ya hecho en LoginFrame)
        setJMenuBar(createMenuBar());

        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("Registro Usuario", crearRegistroUsuario());
        tabs.addTab("Registro Acceso", crearRegistroAcceso());
        tabs.addTab("Administrar Usuarios", crearAdminUsuarios());
        tabs.addTab("Historial Accesos", crearHistorialAccesos());
        tabs.addTab("Estadísticas", crearEstadisticas());

        labelEstado.setForeground(Color.GREEN);

        add(tabs, BorderLayout.CENTER);
        add(labelEstado, BorderLayout.SOUTH);

        // Si rol es USUARIO, ocultar pestañas que no le corresponden
        aplicarPermisosALaInterfaz(tabs);
    }

    private void aplicarPermisosALaInterfaz(JTabbedPane tabs) {
        String role = SessionManager.getRole();
        if (SessionManager.isAdmin()) {
            // todo visible
        } else if (SessionManager.isOperador()) {
            // OPERADOR no debe poder eliminar usuarios ni cambiar roles -> dejamos pestaña Administrar visible pero botones limitados
            // en crearAdminUsuarios() ya aplicamos chequeos para crear/editar/eliminar
        } else {
            // USUARIO -> ocultar pestañas administrativas y de registro de acceso
            // Mantener sólo: Registro Usuario (para ver su propia info), Historial Accesos (sus accesos) y Estadísticas (si quieres, mostrar resumen)
            for (int i = tabs.getTabCount() - 1; i >= 0; i--) {
                String title = tabs.getTitleAt(i);
                if (!title.equals("Historial Accesos") && !title.equals("Estadísticas") && !title.equals("Registro Usuario")) {
                    tabs.remove(i);
                }
            }
        }
    }

    // ---- MENU ----
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menuArchivo = new JMenu("Archivo");
        JMenuItem salir = new JMenuItem("Salir");
        salir.addActionListener(e -> {
            if (refrescoTimer != null) refrescoTimer.cancel();
            dispose();
            System.exit(0);
        });
        menuArchivo.add(salir);

        JMenu menuSesion = new JMenu("Sesión");
        JMenuItem cerrar = new JMenuItem("Cerrar sesión");
        cerrar.addActionListener(e -> {
            if (refrescoTimer != null) refrescoTimer.cancel();
            SessionManager.endSession();
            dispose();
            // volver al login
            SwingUtilities.invokeLater(() -> {
                new LoginFrame(db).setVisible(true);
            });
        });
        menuSesion.add(cerrar);

        menuBar.add(menuArchivo);
        menuBar.add(menuSesion);
        return menuBar;
    }

    // ---- Registro Usuario tab ----
    private JPanel crearRegistroUsuario() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6,6,6,6);
        c.fill = GridBagConstraints.HORIZONTAL;

        JTextField nombre = new JTextField(20);
        JTextField documento = new JTextField(20);
        JTextField correo = new JTextField(20);
        JComboBox<String> rolCombo = new JComboBox<>(new String[]{"USUARIO","OPERADOR", "ADMIN"});
        JButton registrar = new JButton("Registrar Usuario");

        c.gridx = 0; c.gridy = 0; panel.add(new JLabel("Nombre:"), c);
        c.gridx = 1; panel.add(nombre, c);
        c.gridx = 0; c.gridy = 1; panel.add(new JLabel("Documento:"), c);
        c.gridx = 1; panel.add(documento, c);
        c.gridx = 0; c.gridy = 2; panel.add(new JLabel("Correo:"), c);
        c.gridx = 1; panel.add(correo, c);
        c.gridx = 0; c.gridy = 3; panel.add(new JLabel("Rol:"), c);
        c.gridx = 1; panel.add(rolCombo, c);
        c.gridx = 1; c.gridy = 4; panel.add(registrar, c);

        // Solo ADMIN puede crear ADMIN; OPERADOR no puede crear ADMIN
        registrar.addActionListener(e -> {
            try {
                String rolSeleccionado = ((String) rolCombo.getSelectedItem()).toUpperCase();
                if (!SessionManager.isAdmin() && "ADMIN".equalsIgnoreCase(rolSeleccionado)) {
                    mostrarMensaje("No tienes permiso para crear ADMIN.", true);
                    return;
                }
                if (!SessionManager.isAdmin() && SessionManager.isOperador()) {
                    // permitir crear USUARIO u OPERADOR (si quieres restringir más, cambia aquí)
                    if (!("OPERADOR".equalsIgnoreCase(rolSeleccionado) || "USUARIO".equalsIgnoreCase(rolSeleccionado))) {
                        mostrarMensaje("Rol inválido.", true);
                        return;
                    }
                }
                boolean creado = usuarioService.crearUsuario(documento.getText().trim(), nombre.getText().trim(), correo.getText().trim(), rolSeleccionado);
                if (!creado) {
                    mostrarMensaje("⚠️ Ya existe un usuario con ese documento.", true);
                } else {
                    mostrarMensaje("✅ Usuario registrado correctamente.", false);
                    nombre.setText(""); documento.setText(""); correo.setText("");
                }
            } catch (IllegalArgumentException ex) {
                mostrarMensaje("❌ " + ex.getMessage(), true);
            } catch (Exception ex) {
                mostrarMensaje("❌ Error al registrar usuario: " + ex.getMessage(), true);
            }
        });

        // Si no es admin, seleccionar por defecto rol USUARIO o OPERADOR
        if (!SessionManager.isAdmin()) {
            rolCombo.setSelectedItem("USUARIO");
            // opcional: si operador, permitir OPERADOR/USUARIO
        }

        return panel;
    }

    // ---- Registro Acceso tab ----
    private JPanel crearRegistroAcceso() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6,6,6,6);
        c.fill = GridBagConstraints.HORIZONTAL;

        JTextField documento = new JTextField(20);
        JTextField zona = new JTextField(20);
        JComboBox<String> tipoAcceso = new JComboBox<>(new String[]{"entrada", "salida"});
        JButton registrar = new JButton("Registrar Acceso");

        c.gridx = 0; c.gridy = 0; panel.add(new JLabel("Documento:"), c);
        c.gridx = 1; panel.add(documento, c);
        c.gridx = 0; c.gridy = 1; panel.add(new JLabel("Zona:"), c);
        c.gridx = 1; panel.add(zona, c);
        c.gridx = 0; c.gridy = 2; panel.add(new JLabel("Tipo de acceso:"), c);
        c.gridx = 1; panel.add(tipoAcceso, c);
        c.gridx = 1; c.gridy = 3; panel.add(registrar, c);

        registrar.addActionListener(e -> {
            try {
                // Sólo ADMIN y OPERADOR pueden registrar accesos
                if (!SessionManager.isAdmin() && !SessionManager.isOperador()) {
                    mostrarMensaje("No tienes permiso para registrar accesos.", true);
                    return;
                }

                if (Validator.isEmpty(documento.getText()) || Validator.isEmpty(zona.getText())) {
                    mostrarMensaje("Documento y zona son obligatorios.", true);
                    return;
                }
                boolean exito = accesoService.registrarAcceso(documento.getText().trim(), zona.getText().trim(), (String) tipoAcceso.getSelectedItem());
                if (exito) {
                    mostrarMensaje("✅ Acceso registrado correctamente.", false);
                } else {
                    mostrarMensaje("⚠️ Acceso denegado.", true);
                }
            } catch (Exception ex) {
                mostrarMensaje("❌ Error al registrar acceso: " + ex.getMessage(), true);
            }
        });

        return panel;
    }

    // ---- Admin Usuarios tab (lista + CRUD) ----
    private JPanel crearAdminUsuarios() {
        JPanel panel = new JPanel(new BorderLayout());
        JScrollPane scroll = new JScrollPane(listaUsuarios);
        JButton refrescar = new JButton("Listar Usuarios");
        JButton editar = new JButton("Editar Seleccionado");
        JButton eliminar = new JButton("Eliminar Seleccionado");
        JButton crear = new JButton("Crear Usuario (dialog)");

        refrescar.addActionListener(e -> listarUsuarios());
        crear.addActionListener(e -> crearUsuarioDialog(null, panel));
        editar.addActionListener(e -> editarUsuarioSeleccionado());
        eliminar.addActionListener(e -> eliminarUsuarioSeleccionado());

        JPanel botones = new JPanel();
        botones.add(refrescar);
        botones.add(crear);
        botones.add(editar);
        botones.add(eliminar);

        // Si no es ADMIN, ocultar/eliminar botón eliminar
        if (!SessionManager.isAdmin()) {
            eliminar.setEnabled(false);
        }

        panel.add(scroll, BorderLayout.CENTER);
        panel.add(botones, BorderLayout.SOUTH);
        return panel;
    }

    private void crearUsuarioDialog(String documentoInicial, Component parent) {
        JTextField docField = new JTextField(documentoInicial == null ? "" : documentoInicial);
        JTextField nombreField = new JTextField();
        JTextField correoField = new JTextField();
        JComboBox<String> rolCombo = new JComboBox<>(new String[]{"USUARIO","OPERADOR", "ADMIN"});

        // Si no es admin, no permitir seleccionar ADMIN
        if (!SessionManager.isAdmin()) {
            rolCombo.removeItem("ADMIN");
        }

        JPanel p = new JPanel(new GridLayout(0,1));
        p.add(new JLabel("Documento:")); p.add(docField);
        p.add(new JLabel("Nombre:")); p.add(nombreField);
        p.add(new JLabel("Correo:")); p.add(correoField);
        p.add(new JLabel("Rol:")); p.add(rolCombo);

        int res = JOptionPane.showConfirmDialog(this, p, "Crear Usuario", JOptionPane.OK_CANCEL_OPTION);
        if (res != JOptionPane.OK_OPTION) return;

        try {
            String rolSel = ((String) rolCombo.getSelectedItem()).toUpperCase();
            boolean ok = usuarioService.crearUsuario(docField.getText().trim(), nombreField.getText().trim(), correoField.getText().trim(), rolSel);
            if (ok) {
                mostrarMensaje("Usuario creado.", false);
                listarUsuarios();
            } else {
                mostrarMensaje("No se pudo crear (ya existe).", true);
            }
        } catch (Exception ex) {
            mostrarMensaje("Error creando usuario: " + ex.getMessage(), true);
        }
    }

    private void editarUsuarioSeleccionado() {
        String seleccionado = listaUsuarios.getSelectedValue();
        if (seleccionado == null) {
            mostrarMensaje("Selecciona un usuario para editar.", true);
            return;
        }
        String documento = seleccionado.split(" - ")[0];
        try {
            Usuario u = usuarioService.obtener(documento);
            if (u == null) {
                mostrarMensaje("Usuario no encontrado.", true);
                return;
            }

            // Abrimos diálogo de edición (VentanaEditarUsuario) que aplica permisos internos
            VentanaEditarUsuario dlg = new VentanaEditarUsuario(this, db, u);
            dlg.setVisible(true);
            listarUsuarios();

        } catch (Exception ex) {
            mostrarMensaje("Error editando usuario: " + ex.getMessage(), true);
        }
    }

    private void eliminarUsuarioSeleccionado() {
        String seleccionado = listaUsuarios.getSelectedValue();
        if (seleccionado == null) {
            mostrarMensaje("Selecciona un usuario para eliminar.", true);
            return;
        }
        String documento = seleccionado.split(" - ")[0];

        // Solo ADMIN puede eliminar
        if (!SessionManager.isAdmin()) {
            mostrarMensaje("No tienes permiso para eliminar usuarios.", true);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar usuario " + documento + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        try {
            usuarioService.eliminarUsuario(documento);
            listarUsuarios();
            mostrarMensaje("Usuario eliminado correctamente.", false);
        } catch (Exception e) {
            mostrarMensaje("❌ Error al eliminar usuario: " + e.getMessage(), true);
        }
    }

    private void listarUsuarios() {
        datosListaUsuarios.clear();
        try {
            List<Usuario> usuarios = usuarioService.listarUsuarios();
            for (Usuario u : usuarios) {
                datosListaUsuarios.addElement(u.getDocumento() + " - " + u.getNombre() + " - " + u.getCorreo() + " - " + u.getRol());
            }
            mostrarMensaje("Usuarios listados.", false);
        } catch (Exception e) {
            mostrarMensaje("❌ Error al listar usuarios: " + e.getMessage(), true);
        }
    }

    // ---- Historial accesos tab ----
    private JPanel crearHistorialAccesos() {
        JPanel panel = new JPanel(new BorderLayout());
        DefaultListModel<String> modelo = new DefaultListModel<>();
        JList<String> lista = new JList<>(modelo);
        JScrollPane scroll = new JScrollPane(lista);

        JButton refrescar = new JButton("Refrescar");
        JCheckBox autoCheck = new JCheckBox("Auto-refresh (10s)");
        JButton cargar10 = new JButton("Cargar últimos 10");

        JPanel botones = new JPanel();
        botones.add(refrescar); botones.add(cargar10); botones.add(autoCheck);

        refrescar.addActionListener(e -> cargarUltimosAccesos(modelo, 50));
        cargar10.addActionListener(e -> cargarUltimosAccesos(modelo, 10));
        autoCheck.addActionListener(e -> {
            autoRefresh = autoCheck.isSelected();
            if (autoRefresh) startAutoRefresh(modelo);
            else stopAutoRefresh();
        });

        // Si el rol es USUARIO, al refrescar mostramos solo accesos de su documento
        refrescar.addActionListener(e -> {
            if (SessionManager.isUsuario()) cargarUltimosAccesosUsuario(modelo, 50);
            else cargarUltimosAccesos(modelo, 50);
        });

        cargar10.addActionListener(e -> {
            if (SessionManager.isUsuario()) cargarUltimosAccesosUsuario(modelo, 10);
            else cargarUltimosAccesos(modelo, 10);
        });

        panel.add(scroll, BorderLayout.CENTER);
        panel.add(botones, BorderLayout.NORTH);
        return panel;
    }

    private void cargarUltimosAccesos(DefaultListModel<String> modelo, int limit) {
        modelo.clear();
        try {
            List<Acceso> accesos = accesoService.listarUltimos(limit);
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            for (Acceso a : accesos) {
                String line = String.format("%s | %s | zona: %s | %s", a.getFecha().format(fmt), a.getDocumento_persona(), a.getZona(), a.isPermitido() ? "ENTRADA" : "SALIDA");
                modelo.addElement(line);
            }
            mostrarMensaje("Historial cargado.", false);
        } catch (Exception e) {
            mostrarMensaje("Error cargando historial: " + e.getMessage(), true);
        }
    }

    private void cargarUltimosAccesosUsuario(DefaultListModel<String> modelo, int limit) {
        modelo.clear();
        try {
            List<Acceso> accesos = accesoService.listarUltimos(limit);
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            for (Acceso a : accesos) {
                if (!a.getDocumento_persona().equals(SessionManager.getDoc())) continue;
                String line = String.format("%s | %s | zona: %s | %s", a.getFecha().format(fmt), a.getDocumento_persona(), a.getZona(), a.isPermitido() ? "ENTRADA" : "SALIDA");
                modelo.addElement(line);
            }
            mostrarMensaje("Historial (usuario) cargado.", false);
        } catch (Exception e) {
            mostrarMensaje("Error cargando historial: " + e.getMessage(), true);
        }
    }

    private void startAutoRefresh(DefaultListModel<String> modelo) {
        stopAutoRefresh();
        refrescoTimer = new Timer();
        refrescoTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> {
                    if (SessionManager.isUsuario()) cargarUltimosAccesosUsuario(modelo, 50);
                    else cargarUltimosAccesos(modelo, 50);
                });
            }
        }, 0, 10_000);
    }

    private void stopAutoRefresh() {
        if (refrescoTimer != null) {
            refrescoTimer.cancel();
            refrescoTimer = null;
        }
    }

    // ---- Estadisticas tab ----
    private JPanel crearEstadisticas() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel top = new JPanel();
        JButton btnMostrar = new JButton("Mostrar Estadísticas");
        JButton btnActualizar = new JButton("Actualizar estadísticas");
        JButton btnExport = new JButton("Exportar CSV");

        top.add(btnMostrar);
        top.add(btnActualizar);
        top.add(btnExport);

        panel.add(top, BorderLayout.NORTH);

        JTextArea resultados = new JTextArea();
        resultados.setEditable(false);
        panel.add(new JScrollPane(resultados), BorderLayout.CENTER);

        btnMostrar.addActionListener(e -> {
            try {
                Map<String, Integer> conteo = Estadisticas.obtenerConteoEntradasSalidas(db);
                Map<String, Integer> porDia = Estadisticas.accesosPorDia(db);

                StringBuilder sb = new StringBuilder();
                sb.append("Entradas vs Salidas:\n");
                conteo.forEach((k, v) -> sb.append(k).append(": ").append(v).append("\n"));
                sb.append("\nAccesos por Día:\n");
                porDia.forEach((k, v) -> sb.append(k).append(": ").append(v).append("\n"));

                resultados.setText(sb.toString());
                mostrarMensaje("Estadísticas mostradas.", false);
            } catch (Exception ex) {
                mostrarMensaje("❌ Error al generar estadísticas: " + ex.getMessage(), true);
            }
        });

        btnActualizar.addActionListener(e -> {
            btnMostrar.doClick(); // reutiliza la misma acción
            mostrarMensaje("Estadísticas actualizadas.", false);
        });

        btnExport.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            fc.setSelectedFile(new File("estadisticas.csv"));
            int opt = fc.showSaveDialog(this);
            if (opt == JFileChooser.APPROVE_OPTION) {
                File f = fc.getSelectedFile();
                try {
                    exportService.exportarEstadisticasCSV(f);
                    mostrarMensaje("Exportado a " + f.getAbsolutePath(), false);
                } catch (Exception ex) {
                    mostrarMensaje("Error exportando CSV: " + ex.getMessage(), true);
                }
            }
        });

        return panel;
    }

    // ---- Mensajes ----
    private void mostrarMensaje(String mensaje, boolean error) {
        labelEstado.setText(mensaje);
        labelEstado.setForeground(error ? Color.RED : Color.GREEN);
    }
}
