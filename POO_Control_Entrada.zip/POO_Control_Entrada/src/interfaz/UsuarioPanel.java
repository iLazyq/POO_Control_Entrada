package interfaz;

import db.DatabaseHandler;
import servicios.UsuarioService;
import utils.SessionManager;
import modelos.Usuario;

import javax.swing.*;
import java.awt.*;

public class UsuarioPanel extends JPanel {
    private final DatabaseHandler db;
    private final UsuarioService usuarioService;

    public UsuarioPanel(DatabaseHandler db, JFrame parent) {
        this.db = db;
        this.usuarioService = new UsuarioService(db);

        setLayout(new BorderLayout());

        JPanel top = new JPanel();
        JButton btnPerfil = new JButton("Ver mi perfil");
        JButton btnEditar = new JButton("Editar mi perfil");
        top.add(btnPerfil);
        top.add(btnEditar);
        add(top, BorderLayout.NORTH);

        JTextArea area = new JTextArea();
        area.setEditable(false);
        add(new JScrollPane(area), BorderLayout.CENTER);

        // -------------------------
        // BOTÓN VER PERFIL
        // -------------------------
        btnPerfil.addActionListener(e -> {
            try {
                Usuario u = usuarioService.obtener(SessionManager.getDoc());
                if (u == null) {
                    area.setText("No se encontró información del usuario.");
                } else {
                    area.setText(
                            "Documento: " + u.getDocumento() + "\n" +
                            "Nombre: " + u.getNombre() + "\n" +
                            "Correo: " + u.getCorreo() + "\n" +
                            "Rol: " + u.getRol()
                    );
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(
                        this,
                        "Error al obtener el perfil: " + ex.getMessage()
                );
            }
        });

        // -------------------------
        // BOTÓN EDITAR PERFIL
        // -------------------------
        btnEditar.addActionListener(e -> {
            try {
                Usuario u = usuarioService.obtener(SessionManager.getDoc());
                if (u == null) {
                    JOptionPane.showMessageDialog(this, "No se encontró el usuario.");
                    return;
                }

                VentanaEditarUsuario dlg =
                        new VentanaEditarUsuario(
                                (JFrame) SwingUtilities.getWindowAncestor(this),
                                db,
                                u.getDocumento()
                        );

                dlg.setLocationRelativeTo(this);
                dlg.setVisible(true);

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(
                        this,
                        "Error al abrir editor: " + ex.getMessage()
                );
            }
        });
    }
}
