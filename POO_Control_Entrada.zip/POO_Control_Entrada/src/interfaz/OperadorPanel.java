package interfaz;

import db.DatabaseHandler;
import servicios.AccesoService;
import servicios.UsuarioService;
import utils.SessionManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class OperadorPanel extends JPanel {
    private final DatabaseHandler db;
    private final AccesoService accesoService;
    private final UsuarioService usuarioService;

    public OperadorPanel(DatabaseHandler db, JFrame parent) {
        this.db = db;
        this.accesoService = new AccesoService(db);
        this.usuarioService = new UsuarioService(db);

        setLayout(new BorderLayout());
        JPanel top = new JPanel();
        JButton btnRegAcc = new JButton("Registrar Acceso");
        JButton btnUltimos = new JButton("Últimos accesos (50)");
        JButton btnBuscar = new JButton("Buscar usuario");
        top.add(btnRegAcc); top.add(btnUltimos); top.add(btnBuscar);
        add(top, BorderLayout.NORTH);

        JTextArea area = new JTextArea();
        add(new JScrollPane(area), BorderLayout.CENTER);

        btnRegAcc.addActionListener(e -> {
            JTextField doc = new JTextField();
            JTextField zona = new JTextField();
            JComboBox<String> tipo = new JComboBox<>(new String[]{"entrada","salida"});
            JPanel p = new JPanel(new GridLayout(0,1));
            p.add(new JLabel("Documento:")); p.add(doc);
            p.add(new JLabel("Zona:")); p.add(zona);
            p.add(new JLabel("Tipo:")); p.add(tipo);
            if (JOptionPane.showConfirmDialog(this,p,"Registrar",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION) {
                try {
                    boolean ok = accesoService.registrarAcceso(doc.getText().trim(), zona.getText().trim(), (String)tipo.getSelectedItem());
                    JOptionPane.showMessageDialog(this, ok ? "Registrado" : "Denegado");
                } catch (Exception ex) { JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage()); }
            }
        });

        btnUltimos.addActionListener(e -> {
            try {
                List<modelos.Acceso> l = accesoService.listarUltimos(50);
                StringBuilder sb = new StringBuilder();
                var fmt = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                for (var a : l) sb.append(a.getFecha().format(fmt)).append(" | ").append(a.getDocumento_persona()).append(" | ").append(a.getZona()).append(" | ").append(a.isPermitido()?"ENTRADA":"SALIDA").append("\n");
                area.setText(sb.toString());
            } catch (Exception ex) { JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage()); }
        });

        btnBuscar.addActionListener(e -> {
            String doc = JOptionPane.showInputDialog(this, "Documento:");
            if (doc == null || doc.trim().isEmpty()) return;
            try {
                var u = usuarioService.obtener(doc.trim());
                if (u==null) JOptionPane.showMessageDialog(this,"No encontrado");
                else area.setText(u.getDocumento()+" - "+u.getNombre()+" - "+u.getCorreo()+" - "+u.getRol());
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: "+ex.getMessage()); }
        });
    }
}
