package interfaz;

import modelos.Usuario;
import db.DatabaseHandler;
import servicios.UsuarioService;
import utils.SessionManager;

import javax.swing.*;
import java.awt.*;

public class VentanaEditarUsuario extends JDialog {

    private final Usuario usuario;
    private final DatabaseHandler db;
    private final UsuarioService usuarioService;

    private JTextField txtNombre;
    private JTextField txtCorreo;
    private JComboBox<String> comboRol;

    public VentanaEditarUsuario(Frame owner, DatabaseHandler db, Usuario usuario) {
        super(owner, "Editar Usuario", true);
        this.usuario = usuario;
        this.db = db;
        this.usuarioService = new UsuarioService(db);

        setSize(380, 260);
        setLocationRelativeTo(owner);
        setLayout(new GridLayout(0,1,4,4));

        txtNombre = new JTextField(usuario.getNombre());
        txtCorreo = new JTextField(usuario.getCorreo());

        comboRol = new JComboBox<>(new String[]{"ADMIN", "OPERADOR", "USUARIO"});
        comboRol.setSelectedItem(usuario.getRol());

        // Si no es ADMIN, no puede cambiar rol a ADMIN ni editar rol
        if (!SessionManager.isAdmin()) {
            comboRol.setEnabled(false);
        }

        add(new JLabel("Documento: " + usuario.getDocumento()));
        add(new JLabel("Nombre:"));
        add(txtNombre);
        add(new JLabel("Correo:"));
        add(txtCorreo);
        add(new JLabel("Rol:"));
        add(comboRol);

        JButton btnGuardar = new JButton("Guardar cambios");
        btnGuardar.addActionListener(e -> guardarCambios());
        add(btnGuardar);
    }

    private void guardarCambios() {
        try {
            // Sólo ADMIN puede cambiar rol; si no, pasar null para mantener rol
            String nuevoRol = SessionManager.isAdmin() ? comboRol.getSelectedItem().toString() : usuario.getRol();
            usuarioService.actualizarUsuario(usuario.getDocumento(), txtNombre.getText().trim(), txtCorreo.getText().trim(), nuevoRol);
            JOptionPane.showMessageDialog(this, "Usuario actualizado.");
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}
